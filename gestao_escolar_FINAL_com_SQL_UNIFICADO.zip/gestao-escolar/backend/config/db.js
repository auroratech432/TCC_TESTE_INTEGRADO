// Configuração do banco de dados MySQL
