// Backend principal
