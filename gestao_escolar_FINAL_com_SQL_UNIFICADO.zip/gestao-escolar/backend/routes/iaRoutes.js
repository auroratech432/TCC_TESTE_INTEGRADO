// Rota IA gerar
