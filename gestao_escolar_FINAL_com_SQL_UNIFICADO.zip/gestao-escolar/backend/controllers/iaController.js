// Controlador de IA
