# Sistema de Gestão Escolar com IA
