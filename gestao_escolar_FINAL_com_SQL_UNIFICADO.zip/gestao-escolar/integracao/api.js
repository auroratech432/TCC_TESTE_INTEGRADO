// Integração frontend-backend
